# -*- coding: utf-8 -*-
# Parte de Odoo. Ver archivo LICENSE para detalles completos de licencia.

from . import calendar_event
from . import calendar_attendee
from . import calendar_attendee_filter

