# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import pytz
from datetime import datetime
from odoo import models, api, _

class HrAttendanceLunch(models.Model):
    """
    Extensión del modelo hr.attendance para gestionar automáticamente los registros de asistencia durante la hora del almuerzo.
    
    Extension of the hr.attendance model to automatically manage attendance records during lunch time.
    """
    _inherit = 'hr.attendance'

    def _get_employee_local_time(self, employee):
        """
        Obtiene la hora actual en la zona horaria del empleado.
        
        Gets the current time in the employee's timezone.
        
        :param employee: Registro de hr.employee / hr.employee record
        :return: Objeto datetime en la zona horaria del empleado / Datetime object in employee's timezone
        """
        tz = pytz.timezone(employee.tz or 'UTC')
        now_utc = pytz.utc.localize(datetime.now())
        return now_utc.astimezone(tz)
    
    @api.model
    def _process_lunch_break_attendances(self):
        """
        Procesa los registros de asistencia para la pausa del almuerzo:
        - Para empleados cuya hora local es aproximadamente las 12:30 PM
        - Con un registro de asistencia abierto (sin salida)
        - Crea una salida a las 12:00 PM
        - Crea una nueva entrada a las 12:30 PM
        
        Este método es llamado por la acción programada cada 30 minutos.
        
        Process attendance records for lunch break:
        - For employees whose local time is around 12:30 PM
        - With an open attendance record (no check-out)
        - Create a check-out at 12:00 PM
        - Create a new check-in at 12:30 PM
        
        This method is called by the scheduled action every 30 minutes.
        """
        # Obtener todos los empleados con un registro de asistencia abierto
        # Get all employees with an open attendance record
        open_attendances = self.search([('check_out', '=', False)])
        employees_to_process = []
        
        # Verificar la hora local de cada empleado
        # Check each employee's local time
        for attendance in open_attendances:
            employee = attendance.employee_id
            local_time = self._get_employee_local_time(employee)
            
            # Verificar si la hora local está alrededor de las 12:30 PM (entre 12:25 PM y 12:35 PM)
            # Check if the local time is around 12:30 PM (between 12:25 PM and 12:35 PM)
            if local_time.hour == 12 and 25 <= local_time.minute <= 35:
                employees_to_process.append({
                    'employee': employee,
                    'attendance': attendance,
                    'local_time': local_time
                })
        
        # Procesar los empleados identificados
        # Process the identified employees
        for emp_data in employees_to_process:
            employee = emp_data['employee']
            attendance = emp_data['attendance']
            local_time = emp_data['local_time']
            
            # Crear la hora de salida a las 12:00 PM en la zona horaria del empleado
            # Create the checkout time at 12:00 PM in the employee's timezone
            checkout_time_local = local_time.replace(hour=12, minute=0, second=0)
            checkout_time_utc = checkout_time_local.astimezone(pytz.utc).replace(tzinfo=None)
            
            # Crear la hora de entrada a las 12:30 PM en la zona horaria del empleado
            # Create the checkin time at 12:30 PM in the employee's timezone
            checkin_time_local = local_time.replace(hour=12, minute=30, second=0)
            checkin_time_utc = checkin_time_local.astimezone(pytz.utc).replace(tzinfo=None)
            
            # Actualizar el registro de asistencia existente con la hora de salida
            # Update the existing attendance record with the checkout time
            attendance.write({
                'check_out': checkout_time_utc
            })
            
            # Crear un nuevo registro de asistencia con la hora de entrada
            # Create a new attendance record with the checkin time
            self.create({
                'employee_id': employee.id,
                'check_in': checkin_time_utc
            })
            
            # Registrar mensaje en el log para fines de auditoría
            # Log message for audit purposes
            self.env['mail.message'].create({
                'model': 'hr.attendance',
                'res_id': attendance.id,
                'message_type': 'notification',
                'body': _('Automatic lunch break: Check-out created at 12:00 PM and new check-in at 12:30 PM')
            })
            
        return True

